int f1(){
    return 12;
}

int f2(){
    return 14;
}